
import base64, codecs
thecrew = 'aW1wb3J0IHJlcXVlc3RzLHJlLHVybGxpYgoKZnJlZUxpc3QgPSBbXQp1cmwgPSAnaHR0cDovL2ZyZWVzLmljdS9mZWVkLycKcmVmZXJlcjEgPSAnfFJlZmVyZXI9aHR0cDovL3Nzc3RyZWFtLmxpdmUvJwpyZWZlcmVyID0gJ3xSZWZ'
doesnt = 'ypzIlCJu0qUN6Yl9zpzIypl5cL3HiozMfYJ5yqUqipzfgoTy2MF13LKEwnP1zpzIyYJ9hoTyhMF1hMzjgozI0q29lnl1bMP8aPtcbqT1fVQ0tpzIkqJImqUZhM2I0XUIloPxhL29hqTIhqNcgLKEwnPN9VUWyYzAioKOcoTHbWmkcqT'
do = 'VtPlxzLis/PiguKz8pXHMmLis/c291cmNlOlxzXCcoLis/KVwnJyxyZS5ET1RBTEwpLmZpbmRhbGwoaHRtbCkKIyAgICBwcmludCAnX19fX18nICsgc3RyKG1hdGNoKQpmb3IgbmFtZSwgbGluayBpbiBtYXRjaDoKICAgIG5hbWUgP'
drama = 'FOhLJ1yPvNtVPOzpzIyGTymqP5upUOyozDbrlqaLJ1yWmchLJ1yYPqmqUWyLJ0aBzkcozftXlOlMJMypzIlsFxXPvAmL3WcpUDtpaIhplOzpz9gVTuypzHXMTIzVUA0LKW0H2AlnKO0XPx6PvNtVPOlMKE1pz4tMaWyMHkcp3DXVPNX'
respect = '\x72\x6f\x74\x31\x33'
usandyou = eval('\x74\x68\x65\x63\x72\x65\x77') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x6f\x65\x73\x6e\x74\x2c\x20\x72\x65\x73\x70\x65\x63\x74\x29') + eval('\x64\x6f') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x72\x61\x6d\x61\x2c\x20\x72\x65\x73\x70\x65\x63\x74\x29')
eval(compile(base64.b64decode(eval('\x75\x73\x61\x6e\x64\x79\x6f\x75')),'<string>','exec'))