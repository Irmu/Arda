# RTP Play Kodi video addon

Work in progress. Expect it to break.

Disclaimer: This plugin is not official and is not endorsed by RTP