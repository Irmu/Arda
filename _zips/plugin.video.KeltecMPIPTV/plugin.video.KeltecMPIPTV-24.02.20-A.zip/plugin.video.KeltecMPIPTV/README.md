# KeltecMP IPTV download:
# https://gitlab.com/LimaMP/KeltecMPIPTV/-/archive/master/KeltecMPIPTV-master.zip

Addon modificado do PlaylistLoader 1.2.0 por Avigdor https://github.com/avigdork/xbmc-avigdork.

Nao somos responsaveis por colocar o conteudo online, apenas indexamos.

Link encurtado para download: http://bit.ly/KeltecMP-IPTV

Para sugestoes e report de bugs nossa pagina no FB: https://www.facebook.com/groups/KelTec.Media.Play
 (ADD-ON DESCONTINUADO)